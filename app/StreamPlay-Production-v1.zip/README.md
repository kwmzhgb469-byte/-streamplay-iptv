# StreamPlay Production Base

1. Instale Node.js 20+.
2. `npm install`
3. Copie `.env.example` para `.env` e informe as credenciais do Supabase.
4. Execute `supabase/schema.sql` no SQL Editor do Supabase.
5. `npm run dev` ou `npm run build`.

Sem `.env`, o projeto abre em modo demonstração. A autenticação real usa Supabase Auth quando configurado.

Para produção, configure HTTPS, domínio, políticas RLS e os serviços de deploy. Conteúdo/streams devem ser autorizados pelo usuário.
