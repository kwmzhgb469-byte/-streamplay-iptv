
import Hls from 'hls.js'
import './style.css'

const KEY='streamplay_2'
const demoChannels=[
 {name:'Exemplo de canal',group:'Demonstração',url:'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',logo:''}
]
let data=JSON.parse(localStorage.getItem(KEY)||'null')||{
 account:null,iptvs:[],active:0,favorites:[],history:[]
}
let page='home',search='',hls=null
const save=()=>localStorage.setItem(KEY,JSON.stringify(data))
const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))
const p=()=>data.iptvs[data.active]
const channels=()=>p()?.channels?.length?p().channels:demoChannels

function nav(){
 return `<header><div class="brand"><div class="brandIcon">${p()?.logo?`<img src="${p().logo}">`:'▶'}</div><div><b>${esc(p()?.name||'StreamPlay')}</b><small>IPTV Player</small></div></div>
 <nav>${[['home','Início'],['live','Ao vivo'],['movies','Filmes'],['series','Séries'],['favorites','Favoritos']].map(([k,t])=>`<button data-page="${k}" class="${page===k?'on':''}">${t}</button>`).join('')}</nav>
 <button class="gear" data-page="settings">⚙</button></header>`
}
function frame(body){document.querySelector('#app').innerHTML=nav()+`<main>${body}</main>`;bind()}
function login(){
 document.querySelector('#app').innerHTML=`<div class="auth"><div class="authbox"><div class="brandCenter">▶</div><h1>StreamPlay 2.0</h1><p>Conecte sua própria IPTV e assista em uma interface feita para você.</p><input id="email" placeholder="E-mail"><input id="pass" type="password" placeholder="Senha"><button class="primary wide" id="enter">Entrar</button><p class="muted">Modo de teste local. A autenticação real será conectada ao backend na etapa de produção.</p></div></div>`
 document.querySelector('#enter').onclick=()=>{let e=document.querySelector('#email').value.trim();if(!e)return alert('Informe seu e-mail.');data.account={email:e,name:e.split('@')[0]};save();page=data.iptvs.length?'home':'add';render()}
}
function add(){
 frame(`<section class="panel"><span class="tag">MINHA IPTV</span><h1>Adicionar sua IPTV</h1><p>Escolha uma das formas de conexão. O conteúdo precisa ser de uma fonte que você esteja autorizado a usar.</p>
 <div class="tabs"><button class="tab active" data-mode="xtream">Xtream Codes</button><button class="tab" data-mode="m3u">M3U / M3U8</button><button class="tab" data-mode="json">JSON</button></div>
 <div class="grid"><label>Nome da IPTV<input id="name" placeholder="Ex.: Minha IPTV"></label><label>Logo<input id="logo" type="file" accept="image/png,image/jpeg,image/webp"></label>
 <label id="serverBox">Servidor<input id="server" placeholder="https://servidor:porta"></label><label id="userBox">Usuário<input id="user"></label><label id="passBox">Senha<input id="pass" type="password"></label>
 <label class="full" id="urlBox">URL da playlist<input id="url" placeholder="https://.../playlist.m3u"></label></div>
 <button class="primary" id="create">Adicionar IPTV</button><div class="notice">Para produção, as credenciais serão armazenadas em backend seguro. Esta tela não fornece canais próprios.</div></section>`)
 let mode='xtream'
 const toggle=()=>{
   document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.mode===mode))
   const x=mode==='xtream', j=mode==='json'
   document.querySelector('#serverBox').style.display=x?'block':'none'
   document.querySelector('#userBox').style.display=x?'block':'none'
   document.querySelector('#passBox').style.display=x?'block':'none'
   document.querySelector('#urlBox').style.display=x?'none':'block'
   document.querySelector('#url').placeholder=j?'https://.../playlist.json':'https://.../playlist.m3u'
 }
 document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>{mode=b.dataset.mode;toggle()});toggle()
 document.querySelector('#create').onclick=async()=>{
   let file=document.querySelector('#logo').files[0],logo=''
   if(file)logo=await new Promise(r=>{let fr=new FileReader();fr.onload=()=>r(fr.result);fr.readAsDataURL(file)})
   let item={name:document.querySelector('#name').value||'Minha IPTV',logo,mode,server:document.querySelector('#server').value.trim(),username:document.querySelector('#user').value.trim(),password:document.querySelector('#pass').value,url:document.querySelector('#url').value.trim(),channels:[],movies:[],series:[],epg:[]}
   data.iptvs.push(item);data.active=data.iptvs.length-1;save()
   if(mode==='m3u'&&item.url) await importM3U(item.url)
   else if(mode==='json'&&item.url) await importJSON(item.url)
   else if(mode==='xtream'&&item.server&&item.username&&item.password) await importXtream(item)
   save();page='home';render()
 }
}
async function importM3U(url){
 try{let t=await (await fetch(url)).text();data.iptvs[data.active].channels=parseM3U(t)}
 catch(e){alert('M3U não carregada. Verifique URL, HTTPS e CORS.')}
}
function parseM3U(t){
 let out=[],meta=null
 for(let line of t.split(/\r?\n/)){line=line.trim()
  if(line.startsWith('#EXTINF:'))meta=line
  else if(line&&!line.startsWith('#')&&meta){
   let name=meta.split(',').slice(1).join(',').trim()||'Canal'
   let group=(meta.match(/group-title="([^"]*)"/)||[])[1]||'Sem categoria'
   let logo=(meta.match(/tvg-logo="([^"]*)"/)||[])[1]||''
   let epg=(meta.match(/tvg-id="([^"]*)"/)||[])[1]||''
   out.push({name,group,logo,epg,url:line});meta=null
  }
 }return out
}
async function importJSON(url){
 try{let j=await (await fetch(url)).json();let arr=Array.isArray(j)?j:(j.channels||j.items||j.data||[]);data.iptvs[data.active].channels=arr.map(x=>({name:x.name||x.title||'Canal',group:x.group||x.category||'Sem categoria',logo:x.logo||x.icon||'',epg:x.epg||'',url:x.url||x.stream||x.link||''})).filter(x=>x.url)}
 catch(e){alert('JSON não carregado. Confira o formato e o acesso da URL.')}
}
async function importXtream(item){
 try{
  let base=item.server.replace(/\/$/,'')
  let auth=`${base}/player_api.php?username=${encodeURIComponent(item.username)}&password=${encodeURIComponent(item.password)}`
  await (await fetch(auth)).json()
  let list=await (await fetch(`${auth}&action=get_live_streams`)).json()
  let cats=await (await fetch(`${auth}&action=get_live_categories`)).json()
  item.channels=(Array.isArray(list)?list:[]).map(x=>({name:x.name,group:(cats.find(c=>String(c.category_id)===String(x.category_id))?.category_name)||'TV',logo:x.stream_icon||'',epg:x.epg_channel_id||'',url:`${base}/live/${encodeURIComponent(item.username)}/${encodeURIComponent(item.password)}/${x.stream_id}.m3u8`}))
 }catch(e){alert('Não foi possível importar Xtream. Verifique servidor, usuário, senha e CORS.')}
}
function home(){
 let q=channels().length
 frame(`<section class="hero"><div><span class="tag">STREAMPLAY 2.0</span><h1>${esc(p()?.name||'Sua IPTV')}<br><em>do seu jeito.</em></h1><p>Conecte sua própria fonte, use seu logo e organize TV ao vivo, filmes, séries, EPG e favoritos.</p><button class="primary big" data-page="live">Assistir ao vivo</button><button class="outline big" data-page="add">Adicionar IPTV</button></div><div class="logoHero">${p()?.logo?`<img src="${p().logo}">`:'▶'}</div></section>
 <div class="stats"><div><b>${q}</b><small>Canais</small></div><div><b>${p()?.movies?.length||0}</b><small>Filmes</small></div><div><b>${data.favorites.length}</b><small>Favoritos</small></div></div>
 <section class="panel"><h2>Minha IPTV</h2><p class="muted">Sua identidade e sua fonte ficam associadas à conta deste dispositivo.</p><button class="secondary" data-page="settings">Configurar</button></section>`)
}
function live(){
 let list=channels().filter(c=>`${c.name} ${c.group}`.toLowerCase().includes(search.toLowerCase()))
 frame(`<div class="head"><div><span class="tag">TV AO VIVO</span><h1>Canais</h1></div><button class="secondary" data-page="add">+ IPTV</button></div><div class="toolbar"><input id="search" value="${esc(search)}" placeholder="Pesquisar canais..."></div><div id="player"></div><div class="cards">${list.map(c=>{let i=channels().indexOf(c);return card(c,i)}).join('')}</div>`)
 document.querySelector('#search').oninput=e=>{search=e.target.value;live()};bindCards()
}
function card(c,i){
 return `<article class="card"><button class="cardmain" data-play="${i}"><div class="ch">${c.logo?`<img src="${c.logo}">`:'TV'}</div><b>${esc(c.name)}</b><small>${esc(c.group||'')}</small></button><button class="fav" data-fav="${i}">${data.favorites.includes(c.name)?'★':'☆'}</button></article>`
}
function bindCards(){
 document.querySelectorAll('[data-play]').forEach(b=>b.onclick=()=>play(channels()[+b.dataset.play]))
 document.querySelectorAll('[data-fav]').forEach(b=>b.onclick=()=>{let n=channels()[+b.dataset.fav].name;data.favorites=data.favorites.includes(n)?data.favorites.filter(x=>x!==n):[...data.favorites,n];save();render()})
}
function play(c){
 let box=document.querySelector('#player');if(!box)return
 if(hls){hls.destroy();hls=null}
 box.innerHTML=`<div class="player"><div class="playerbar"><b>${esc(c.name)}</b><button class="ghost" id="close">Fechar</button></div><video id="video" controls autoplay playsinline></video><small id="status">Conectando...</small></div>`
 data.history=[c.name,...data.history.filter(x=>x!==c.name)].slice(0,50);save()
 document.querySelector('#close').onclick=()=>{if(hls){hls.destroy();hls=null}box.innerHTML=''}
 let v=document.querySelector('#video'),s=document.querySelector('#status')
 if(!c.url)return s.textContent='Este item não possui URL de reprodução.'
 if(c.url.includes('.m3u8')&&Hls.isSupported()){hls=new Hls();hls.loadSource(c.url);hls.attachMedia(v);hls.on(Hls.Events.MANIFEST_PARSED,()=>s.textContent='Reprodução iniciada');hls.on(Hls.Events.ERROR,()=>s.textContent='Fluxo indisponível ou bloqueado.')}
 else{v.src=c.url;v.onloadeddata=()=>s.textContent='Reprodução iniciada';v.onerror=()=>s.textContent='Não foi possível reproduzir o fluxo.'}
}
function vod(kind){
 let list=p()?.[kind]||[], term=search.toLowerCase()
 frame(`<div class="head"><div><span class="tag">VOD</span><h1>${kind==='movies'?'Filmes':'Séries'}</h1></div></div><div class="toolbar"><input id="search" value="${esc(search)}" placeholder="Pesquisar..."></div>${list.length?`<div class="cards">${list.filter(x=>String(x.name).toLowerCase().includes(term)).map(x=>`<article class="card"><div class="cardmain"><div class="ch">${x.logo?`<img src="${x.logo}">`:'VOD'}</div><b>${esc(x.name)}</b><small>Conteúdo da sua IPTV</small></div></article>`).join('')}</div>`:'<div class="empty">Nenhum conteúdo carregado.</div>'}`)
 document.querySelector('#search').oninput=e=>{search=e.target.value;vod(kind)}
}
function favorites(){
 let list=channels().filter(x=>data.favorites.includes(x.name))
 frame(`<div class="head"><div><span class="tag">SALVOS</span><h1>Favoritos</h1></div></div>${list.length?`<div class="cards">${list.map(c=>card(c,channels().indexOf(c))).join('')}</div>`:'<div class="empty">Nenhum favorito.</div>'}`);bindCards()
}
function settings(){
 frame(`<section class="panel"><span class="tag">CONFIGURAÇÕES</span><h1>Minha IPTV</h1><div class="settingsRow"><div class="logoHero small">${p()?.logo?`<img src="${p().logo}">`:'▶'}</div><div><b>${esc(p()?.name||'Sem IPTV')}</b><p class="muted">${data.iptvs.length} IPTV(s) cadastrada(s).</p></div></div>
 <div class="iptvList">${data.iptvs.map((x,i)=>`<button class="${i===data.active?'selected':''}" data-activate="${i}">${x.logo?`<img src="${x.logo}">`:''}<span>${esc(x.name)}</span></button>`).join('')}</div>
 <button class="primary" data-page="add">Adicionar outra IPTV</button><button class="outline" id="clear">Apagar dados</button></section>`)
 document.querySelectorAll('[data-activate]').forEach(b=>b.onclick=()=>{data.active=+b.dataset.activate;save();render()})
 document.querySelector('#clear').onclick=()=>{if(confirm('Apagar todos os dados locais?')){localStorage.removeItem(KEY);location.reload()}}
}
function bind(){document.querySelectorAll('[data-page]').forEach(b=>b.onclick=()=>{page=b.dataset.page;search='';render()})}
function render(){if(!data.account)return login();if(!data.iptvs.length)return add();if(page==='home')home();else if(page==='add')add();else if(page==='live')live();else if(page==='movies')vod('movies');else if(page==='series')vod('series');else if(page==='favorites')favorites();else settings()}
render()
