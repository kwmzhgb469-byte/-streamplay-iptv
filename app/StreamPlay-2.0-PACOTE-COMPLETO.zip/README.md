# StreamPlay IPTV 2.0

Pacote completo de base para um player IPTV pessoal.

## Funcionalidades
Login demo, múltiplas IPTV, Xtream, M3U/M3U8, JSON, logos, canais, pesquisa,
favoritos, histórico, player HLS, estrutura de VOD/séries/EPG e configurações.

## Produção
Veja `PRODUCAO-CHECKLIST.md`, `ARQUITETURA.md` e `supabase/schema.sql`.
A conexão real com Auth/Database/Storage precisa das credenciais do projeto
Supabase do proprietário e não pode ser inventada pelo aplicativo.

## Comandos
npm install
npm run build

A saída para hospedagem é `dist/`.
