# Arquitetura planejada

Browser/PWA
  |
  +-- Auth (Supabase)
  +-- Perfil
  +-- Minhas IPTV
  +-- Importador Xtream/M3U/JSON
  +-- TV ao vivo
  +-- VOD (filmes)
  +-- Séries / temporadas / episódios
  +-- EPG
  +-- Favoritos
  +-- Histórico / continuar assistindo
  +-- Controle parental
  +-- Player HLS
  |
Backend/Edge Functions
  +-- validação e importação de fontes
  +-- armazenamento seguro das credenciais
  +-- normalização de catálogo
  +-- proxy apenas quando tecnicamente necessário e permitido
  |
Supabase
  +-- Auth
  +-- Postgres + RLS
  +-- Storage (logos)
