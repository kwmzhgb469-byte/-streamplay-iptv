
create extension if not exists pgcrypto;

create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 display_name text,
 created_at timestamptz not null default now()
);

create table if not exists public.iptv_sources (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 name text not null,
 logo_url text,
 source_type text not null check(source_type in ('xtream','m3u','json')),
 server_url text,
 username text,
 password_encrypted text,
 playlist_url text,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);

create table if not exists public.favorites (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 iptv_id uuid not null references public.iptv_sources(id) on delete cascade,
 item_type text not null,
 item_key text not null,
 item_name text not null,
 created_at timestamptz not null default now(),
 unique(user_id,iptv_id,item_type,item_key)
);

create table if not exists public.watch_history (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 iptv_id uuid not null references public.iptv_sources(id) on delete cascade,
 item_type text not null,
 item_key text not null,
 item_name text not null,
 position_seconds integer not null default 0,
 duration_seconds integer not null default 0,
 updated_at timestamptz not null default now(),
 unique(user_id,iptv_id,item_type,item_key)
);

create table if not exists public.parental_settings (
 user_id uuid primary key references auth.users(id) on delete cascade,
 pin_hash text,
 enabled boolean not null default false
);

alter table public.profiles enable row level security;
alter table public.iptv_sources enable row level security;
alter table public.favorites enable row level security;
alter table public.watch_history enable row level security;
alter table public.parental_settings enable row level security;

create policy "own profile" on public.profiles for all to authenticated
using(id=auth.uid()) with check(id=auth.uid());

create policy "own iptv" on public.iptv_sources for all to authenticated
using(user_id=auth.uid()) with check(user_id=auth.uid());

create policy "own favorites" on public.favorites for all to authenticated
using(user_id=auth.uid()) with check(user_id=auth.uid());

create policy "own history" on public.watch_history for all to authenticated
using(user_id=auth.uid()) with check(user_id=auth.uid());

create policy "own parental" on public.parental_settings for all to authenticated
using(user_id=auth.uid()) with check(user_id=auth.uid());

insert into storage.buckets(id,name,public)
values('iptv-logos','iptv-logos',true)
on conflict(id) do nothing;

create policy "logo public read" on storage.objects for select to public
using(bucket_id='iptv-logos');

create policy "logo owner insert" on storage.objects for insert to authenticated
with check(bucket_id='iptv-logos' and (storage.foldername(name))[1]=auth.uid()::text);

create policy "logo owner update" on storage.objects for update to authenticated
using(bucket_id='iptv-logos' and (storage.foldername(name))[1]=auth.uid()::text);

create policy "logo owner delete" on storage.objects for delete to authenticated
using(bucket_id='iptv-logos' and (storage.foldername(name))[1]=auth.uid()::text);
