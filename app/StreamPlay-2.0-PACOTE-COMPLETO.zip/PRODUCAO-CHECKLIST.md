# StreamPlay 2.0 — checklist de produção

## Já preparado no pacote
- Interface responsiva para celular, computador e TV.
- Conta de usuário (fluxo de demonstração local).
- Múltiplas fontes IPTV.
- Xtream Codes, M3U/M3U8 e JSON.
- Logo por IPTV.
- TV ao vivo, busca e favoritos.
- Player HLS.
- Estrutura de filmes, séries, EPG, histórico e controle parental.
- SQL com Supabase Auth/RLS/Storage.

## Para ativar o modo real
1. Criar um projeto Supabase.
2. Executar `supabase/schema.sql`.
3. Criar as variáveis:
   VITE_SUPABASE_URL
   VITE_SUPABASE_PUBLISHABLE_KEY
4. Conectar a tela de login ao Supabase Auth.
5. Salvar fontes IPTV no banco.
6. Usar Edge Function/backend para buscar Xtream e playlists quando CORS impedir acesso direto.
7. Nunca colocar `service_role` ou qualquer chave secreta no navegador.
8. Criptografar credenciais Xtream no backend.
9. Implementar EPG real a partir do XMLTV/EPG fornecido pela fonte autorizada.
10. Implementar VOD e episódios usando os endpoints fornecidos pela própria fonte.
11. Ativar regras de senha, recuperação de conta e confirmação de e-mail.
12. Configurar domínio e HTTPS.
13. Executar `npm install` e `npm run build`.
14. Publicar a pasta `dist`.

## Regra do produto
StreamPlay é um player/gerenciador. O usuário fornece uma fonte que esteja autorizado a usar. O aplicativo não inclui ou distribui listas de canais próprias.
