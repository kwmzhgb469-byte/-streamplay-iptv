import { createClient } from '@supabase/supabase-js'
import Hls from 'hls.js'
import './style.css'

const url = import.meta.env.VITE_SUPABASE_URL
const key = import.meta.env.VITE_SUPABASE_ANON_KEY
const online = !!(url && key)
const db = online ? createClient(url, key) : null

const demo = [
  { id:'demo-1', name:'Teste HLS', group_name:'Demonstração', logo:'', url:'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8', type:'live' }
]

const KEY = 'streamplay_v2'
let s = {
  user:null, channels:[], favorites:new Set(), recent:[],
  hls:null, current:null, view:'home', query:'', group:'',
  source:'local'
}
const app = document.querySelector('#app')
const esc = x => String(x ?? '').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))

function persist(){
  localStorage.setItem(KEY, JSON.stringify({
    favorites:[...s.favorites], recent:s.recent.slice(0,10)
  }))
}
function restore(){
  try{
    const x=JSON.parse(localStorage.getItem(KEY)||'{}')
    s.favorites=new Set(x.favorites||[])
    s.recent=x.recent||[]
  }catch{}
}
function loginScreen(){
  app.innerHTML=`<div class="login"><div class="login-card">
    <div class="logo-word">Stream<span>Play</span></div>
    <h1>Player IPTV</h1>
    <p class="muted">${online?'Entre na sua conta para sincronizar seus dados.':'Modo demonstração — você pode testar o player sem Supabase.'}</p>
    <input id="email" type="email" placeholder="E-mail">
    <input id="pass" type="password" placeholder="Senha (6+ caracteres)">
    <button id="enter" class="primary wide">${online?'Entrar':'Entrar em demonstração'}</button>
    ${online?'<button id="signup" class="secondary wide">Criar conta</button>':''}
    <button id="demoLogin" class="link wide">Usar demonstração</button>
    <div class="note">Use somente playlists e streams que você tenha autorização para acessar.</div>
  </div></div>`
  document.querySelector('#enter').onclick=auth
  document.querySelector('#signup')?.addEventListener('click',signup)
  document.querySelector('#demoLogin').onclick=()=>{s.user={email:'Demonstração'};s.channels=[...demo];start()}
}
async function auth(){
  const email=document.querySelector('#email').value.trim(), password=document.querySelector('#pass').value
  if(!email||password.length<6)return alert('Informe e-mail e senha com 6+ caracteres.')
  if(!online){s.user={email};start();return}
  const {data,error}=await db.auth.signInWithPassword({email,password})
  if(error)return alert(error.message)
  s.user=data.user;start()
}
async function signup(){
  const email=document.querySelector('#email').value.trim(), password=document.querySelector('#pass').value
  if(!email||password.length<6)return alert('Informe e-mail e senha com 6+ caracteres.')
  const {error}=await db.auth.signUp({email,password})
  alert(error?error.message:'Conta criada. Verifique o e-mail se a confirmação estiver habilitada.')
}
async function logout(){
  if(online)await db.auth.signOut()
  s.user=null;s.channels=[];loginScreen()
}

function shell(){
  app.innerHTML=`<div class="app-shell">
    <aside class="sidebar">
      <div class="brand"><div class="brand-mark">▶</div><div class="logo-word">Stream<span>Play</span></div></div>
      <div class="profile"><div class="avatar">${esc((s.user?.email||'D').slice(0,1).toUpperCase())}</div><div><b>${esc((s.user?.email||'Demonstração').split('@')[0])}</b><small>Conta ativa</small></div></div>
      <nav class="side-nav">
        ${navBtn('home','⌂','Início')}
        ${navBtn('live','▣','TV ao vivo')}
        ${navBtn('movies','◉','Filmes')}
        ${navBtn('series','▤','Séries')}
        ${navBtn('fav','★','Favoritos')}
        ${navBtn('lists','☷','Playlists')}
      </nav>
      <div class="sidebar-bottom"><button id="out" class="ghost wide">↪ Sair</button></div>
    </aside>
    <main class="content">
      <header class="topbar">
        <button id="mobileMenu" class="icon-btn">☰</button>
        <div class="top-title" id="pageTitle">Início</div>
        <div class="grow"></div>
        <button id="searchBtn" class="icon-btn">⌕</button>
        <span class="user-pill">${esc(s.user?.email||'Demonstração')}</span>
      </header>
      <section id="page"></section>
    </main>
  </div>`
  document.querySelectorAll('[data-view]').forEach(b=>b.onclick=()=>show(b.dataset.view))
  document.querySelector('#out').onclick=logout
  document.querySelector('#searchBtn').onclick=()=>{show('live');setTimeout(()=>document.querySelector('#q')?.focus(),50)}
  document.querySelector('#mobileMenu').onclick=()=>document.querySelector('.sidebar').classList.toggle('open')
  show(s.view)
}
function navBtn(id,icon,label){return `<button data-view="${id}" class="${s.view===id?'active':''}"><span>${icon}</span>${label}</button>`}

function show(id){
  s.view=id
  document.querySelectorAll('[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===id))
  const titles={home:'Início',live:'TV ao vivo',movies:'Filmes',series:'Séries',fav:'Favoritos',lists:'Playlists'}
  document.querySelector('#pageTitle').textContent=titles[id]||'StreamPlay'
  if(id==='home')renderHome()
  if(id==='live')renderCatalog('live')
  if(id==='movies')renderCatalog('movie')
  if(id==='series')renderCatalog('series')
  if(id==='fav')renderFav()
  if(id==='lists')renderLists()
}

function renderHome(){
  const groups=new Set(s.channels.map(x=>x.group_name).filter(Boolean)).size
  const rec=s.recent.map(r=>s.channels.find(c=>c.id===r.id)||r).filter(Boolean)
  document.querySelector('#page').innerHTML=`
    <div class="hero">
      <div class="hero-copy">
        <span class="eyebrow">STREAMPLAY 2.0</span>
        <h1>Seu entretenimento,<br><span>em um só lugar.</span></h1>
        <p>Organize playlists M3U, encontre seus canais e reproduza conteúdo compatível em uma interface feita para celular, computador e TV.</p>
        <div class="hero-actions"><button id="addHero" class="primary">＋ Adicionar playlist</button><button id="demoHero" class="secondary">▶ Testar demonstração</button></div>
      </div>
      <div class="hero-orb"><div class="orb-play">▶</div><span>PLAYER IPTV</span></div>
    </div>
    <div class="stat-row">
      <div class="stat"><span>TV ao vivo</span><b>${s.channels.filter(c=>c.type==='live'||!c.type).length}</b></div>
      <div class="stat"><span>Filmes</span><b>${s.channels.filter(c=>c.type==='movie').length}</b></div>
      <div class="stat"><span>Séries</span><b>${s.channels.filter(c=>c.type==='series').length}</b></div>
      <div class="stat"><span>Favoritos</span><b>${s.favorites.size}</b></div>
    </div>
    <div class="section-head"><div><h2>Continue assistindo</h2><p>Seus últimos canais reproduzidos</p></div></div>
    ${rec.length?cards(rec):'<div class="empty">Você ainda não reproduziu nenhum conteúdo.</div>'}
    <div class="section-head"><div><h2>Acesso rápido</h2><p>Comece por onde quiser</p></div></div>
    <div class="quick-grid">
      <button data-view="live" class="quick"><b>TV ao vivo</b><small>Canais e grupos</small></button>
      <button data-view="movies" class="quick"><b>Filmes</b><small>Biblioteca de vídeos</small></button>
      <button data-view="series" class="quick"><b>Séries</b><small>Temporadas e episódios</small></button>
      <button data-view="lists" class="quick"><b>Playlists</b><small>Importar M3U</small></button>
    </div>`
  document.querySelector('#addHero').onclick=()=>show('lists')
  document.querySelector('#demoHero').onclick=()=>{s.channels=[...demo];show('live')}
  document.querySelectorAll('.quick').forEach(b=>b.onclick=()=>show(b.dataset.view))
  bindCards()
}

function renderCatalog(type){
  const items=s.channels.filter(c=type==='live'?(c.type==='live'||!c.type):c.type===type)
  const groups=[...new Set(items.map(x=>x.group_name||'Sem grupo'))].sort()
  document.querySelector('#page').innerHTML=`
    <div class="catalog-head"><div><h1>${type==='live'?'TV ao vivo':type==='movie'?'Filmes':'Séries'}</h1><p class="muted">${items.length} itens disponíveis</p></div></div>
    <div class="toolbar"><input id="q" value="${esc(s.query)}" placeholder="Pesquisar por nome..."><select id="g"><option value="">Todos os grupos</option>${groups.map(x=>`<option ${x===s.group?'selected':''}>${esc(x)}</option>`).join('')}</select></div>
    <div id="grid"></div>
    <div id="playerBox" class="player-box hidden"></div>`
  document.querySelector('#q').oninput=e=>{s.query=e.target.value;renderGrid(items)}
  document.querySelector('#g').onchange=e=>{s.group=e.target.value;renderGrid(items)}
  renderGrid(items)
}
function renderGrid(base){
  const q=s.query.toLowerCase(),g=s.group
  const a=base.filter(c=>(!g||(c.group_name||'Sem grupo')===g)&&(!q||c.name.toLowerCase().includes(q)))
  document.querySelector('#grid').innerHTML=cards(a)
  bindCards()
}
function cards(a){
  if(!a.length)return '<div class="empty">Nenhum item encontrado. Importe uma playlist para começar.</div>'
  return `<div class="cards">${a.map(c=>`
    <article class="channel-card">
      <button class="star" data-star="${esc(c.id)}">${s.favorites.has(c.id)?'★':'☆'}</button>
      <button class="channel-main" data-play="${esc(c.id)}">
        <div class="poster">${c.logo?`<img src="${esc(c.logo)}" onerror="this.style.display='none'">`:'▶'}</div>
        <div class="channel-info"><b>${esc(c.name)}</b><small>${esc(c.group_name||'Sem grupo')}</small></div>
      </button>
    </article>`).join('')}</div>`
}
function bindCards(){
  document.querySelectorAll('[data-play]').forEach(b=>b.onclick=()=>play(b.dataset.play))
  document.querySelectorAll('[data-star]').forEach(b=>b.onclick=()=>fav(b.dataset.star))
}

function renderFav(){
  document.querySelector('#page').innerHTML=`<div class="catalog-head"><div><h1>Favoritos</h1><p class="muted">Seus canais e conteúdos salvos</p></div></div>${cards(s.channels.filter(c=>s.favorites.has(c.id)))}`;bindCards()
}
function renderLists(){
  document.querySelector('#page').innerHTML=`
    <div class="catalog-head"><div><h1>Playlists</h1><p class="muted">Adicione sua lista M3U ou teste uma conexão compatível.</p></div></div>
    <div class="playlist-grid">
      <div class="panel-card"><div class="card-icon">M3U</div><h2>Importar playlist</h2><p>Selecione um arquivo .m3u, .m3u8 ou .txt. O conteúdo é processado no seu navegador.</p><input id="file" type="file" accept=".m3u,.m3u8,.txt"><button id="imp" class="primary wide">Importar arquivo</button></div>
      <div class="panel-card"><div class="card-icon">API</div><h2>Login Xtream</h2><p>Estrutura pronta para conexão com serviços compatíveis com Xtream Codes. O servidor precisa permitir a comunicação.</p>
        <input id="xcUrl" placeholder="URL do servidor">
        <input id="xcUser" placeholder="Usuário">
        <input id="xcPass" type="password" placeholder="Senha">
        <button id="xc" class="secondary wide">Conectar</button>
        <small class="muted">A conexão depende de CORS, autenticação e regras do provedor.</small>
      </div>
    </div>`
  document.querySelector('#imp').onclick=importFile
  document.querySelector('#xc').onclick=()=>alert('A tela de login Xtream está preparada. A integração completa depende do endpoint/API do seu provedor e das permissões de acesso.')
}
function parse(text){
  const out=[];let meta=null
  for(const raw of text.replace(/^﻿/,'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean)){
    if(raw.startsWith('#EXTINF')){
      const i=raw.indexOf(','), name=i>=0?raw.slice(i+1).trim():'Canal'
      const attrs={};for(const a of raw.match(/([\w-]+)="([^"]*)"/g)||[]){const z=a.match(/^([\w-]+)="(.*)"$/);if(z)attrs[z[1].toLowerCase()]=z[2]}
      const group=attrs['group-title']||'Sem grupo'
      const lower=group.toLowerCase()
      const type=/movie|filme|vod/.test(lower)?'movie':/series|série/.test(lower)?'series':'live'
      meta={id:crypto.randomUUID(),name,group_name:group,logo:attrs['tvg-logo']||'',type}
    }else if(!raw.startsWith('#')&&meta){out.push({...meta,url:raw});meta=null}
  }
  return out
}
async function importFile(){
  const f=document.querySelector('#file').files[0];if(!f)return alert('Escolha um arquivo M3U.')
  const a=parse(await f.text());if(!a.length)return alert('Nenhum item M3U válido.')
  s.channels=a;s.query='';s.group='';s.source=f.name
  alert(`${a.length} itens importados de ${f.name}.`)
  if(online)await savePlaylist(f.name,a)
  show('home')
}
async function savePlaylist(name,a){
  const {data:p,error}=await db.from('playlists').insert({user_id:s.user.id,name}).select().single()
  if(error)return console.warn(error.message)
  const rows=a.map(c=>({playlist_id:p.id,name:c.name,url:c.url,group_name:c.group_name,logo:c.logo}))
  const {error:e}=await db.from('channels').insert(rows);if(e)console.warn(e.message)
}
function fav(id){
  s.favorites.has(id)?s.favorites.delete(id):s.favorites.add(id);persist()
  if(s.view==='fav')renderFav();else show(s.view)
}
function play(id){
  const c=s.channels.find(x=>x.id===id);if(!c)return
  s.current=c;s.recent=[c,...s.recent.filter(x=>x.id!==id)].slice(0,10);persist()
  let box=document.querySelector('#playerBox')
  if(!box){document.querySelector('#grid')?.insertAdjacentHTML('afterend','<div id="playerBox" class="player-box"></div>');box=document.querySelector('#playerBox')}
  box.classList.remove('hidden')
  box.innerHTML=`<div class="video-wrap"><video id="video" controls playsinline></video><button id="closePlayer" class="close">×</button></div><div class="player-meta"><div><span class="eyebrow">REPRODUZINDO AGORA</span><h2>${esc(c.name)}</h2><p class="muted">${esc(c.group_name||'Sem grupo')}</p></div><button id="favNow" class="secondary">${s.favorites.has(c.id)?'★ Favorito':'☆ Favoritar'}</button></div>`
  document.querySelector('#closePlayer').onclick=()=>box.classList.add('hidden')
  document.querySelector('#favNow').onclick=()=>fav(c.id)
  const v=document.querySelector('#video')
  if(s.hls)s.hls.destroy()
  s.hls=null;v.removeAttribute('src')
  if(c.url.includes('.m3u8')&&Hls.isSupported()){
    s.hls=new Hls();s.hls.loadSource(c.url);s.hls.attachMedia(v)
    s.hls.on(Hls.Events.MANIFEST_PARSED,()=>v.play().catch(()=>{}))
    s.hls.on(Hls.Events.ERROR,(_,d)=>{if(d.fatal)alert('Stream indisponível ou bloqueado pelo servidor.')})
  }else{v.src=c.url;v.play().catch(()=>{})}
  box.scrollIntoView({behavior:'smooth',block:'start'})
}
async function loadData(){
  if(!online||!s.user)return
  const {data}=await db.from('playlists').select('id,name,channels(*)').eq('user_id',s.user.id)
  s.channels=(data||[]).flatMap(p=>(p.channels||[]).map(c=>({...c,playlist:p.name,type:'live'})))
  if(s.channels.length)show('home')
}
restore()
function start(){shell();loadData()}
if(online){
  db.auth.getSession().then(({data})=>{s.user=data.session?.user||null;s.user?start():loginScreen()})
}else loginScreen()
