# StreamPlay IPTV 2.0

Versão atualizada a partir do pacote enviado pelo usuário.

## O que foi melhorado
- Interface IPTV moderna, responsiva e com navegação lateral.
- Dashboard com estatísticas e acesso rápido.
- TV ao vivo, Filmes, Séries, Favoritos e Playlists.
- Busca e filtro por grupo.
- Player HLS com controles e fechamento.
- Histórico local de "continue assistindo".
- Favoritos persistidos no navegador.
- Importação de playlists M3U/M3U8/TXT.
- Estrutura inicial de tela para conexão Xtream Codes.
- Mantida a integração existente com Supabase Auth e banco.
- Mantido o aviso de uso apenas de conteúdo autorizado.

## Executar
1. Node.js 20+
2. `npm install`
3. Configure `.env` com Supabase quando quiser autenticação/banco.
4. `npm run dev` ou `npm run build`.

A integração Xtream depende do endpoint do provedor, CORS, autenticação e permissões. A tela foi preparada sem incluir credenciais ou serviços de terceiros.
